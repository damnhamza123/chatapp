﻿Partial Class stu1DataSet
    Partial Class finger_matchDataTable

        Private Sub finger_matchDataTable_finger_matchRowChanging(sender As Object, e As finger_matchRowChangeEvent) Handles Me.finger_matchRowChanging

        End Sub

    End Class

    Partial Class matchDataTable

    End Class

End Class

Namespace stu1DataSetTableAdapters

    Partial Class matchTableAdapter

        Sub InsertQuery()
            Throw New NotImplementedException
        End Sub

    End Class

    Partial Public Class loginTableAdapter
    End Class
End Namespace
